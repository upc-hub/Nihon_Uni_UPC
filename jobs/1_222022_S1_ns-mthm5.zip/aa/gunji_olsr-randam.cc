#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include "ns3/command-line.h"
#include "ns3/config.h"
#include "ns3/uinteger.h"
#include "ns3/double.h"
#include "ns3/string.h"
#include "ns3/log.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/mobility-helper.h"
#include "ns3/ipv4-address-helper.h"
#include "ns3/yans-wifi-channel.h"
#include "ns3/mobility-model.h"
#include "ns3/olsr-helper.h"
#include "ns3/ipv4-static-routing-helper.h"
#include "ns3/ipv4-list-routing-helper.h"
#include "ns3/internet-stack-helper.h"
#include "ns3/node-list.h"
#include "ns3/olsr-routing-protocol.h"
#include "ns3/netanim-module.h"
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define SET 40
#define DELAY 4
#define SIZE 2400
#define NODE_NUM_POINT 20
#define NODE_NUM_CON 30

using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("WifiSimpleAdhocGrid");



void ReceivePacket (Ptr<Socket> socket)
{
  while (socket->Recv ())
    {
      NS_LOG_UNCOND ("Received one packet!");
    }
}

static void GenerateTraffic (Ptr<Socket> socket, uint32_t pktSize,
                             uint32_t pktCount, Time pktInterval )
{
  if (pktCount > 0)
    {
      //NS_LOG_UNCOND ("Send one packet!");
      socket->Send (Create<Packet> (pktSize));
      Simulator::Schedule (pktInterval, &GenerateTraffic,
                           socket, pktSize,pktCount - 1, pktInterval);
    }
  else
    {
      socket->Close ();
    }
}


int main (int argc, char *argv[])
{
  std::string phyMode ("DsssRate1Mbps");
  double distance = 500;  // m
  uint32_t packetSize = 100; // bytes
  uint32_t numPackets = 1;
  uint32_t numNodes = 0;  // by default, 5x5
  uint32_t sinkNode = 0;
  uint32_t sourceNode = 20;
  double interval = 1.0; // seconds
  bool verbose = false;
  bool tracing = false;
  
  CommandLine cmd;
  cmd.AddValue ("phyMode", "Wifi Phy mode", phyMode);
  cmd.AddValue ("distance", "distance (m)", distance);
  cmd.AddValue ("packetSize", "size of application packet sent", packetSize);
  cmd.AddValue ("numPackets", "number of packets generated", numPackets);
  cmd.AddValue ("interval", "interval (seconds) between packets", interval);
  cmd.AddValue ("verbose", "turn on all WifiNetDevice log components", verbose);
  cmd.AddValue ("tracing", "turn on ascii and pcap tracing", tracing);
  cmd.AddValue ("numNodes", "number of nodes", numNodes);
  cmd.AddValue ("sinkNode", "Receiver node number", sinkNode);
  cmd.AddValue ("sourceNode", "Sender node number", sourceNode);
  cmd.Parse (argc, argv);
  // Convert to time object
  Time interPacketInterval = Seconds (interval);
  
  // Fix non-unicast data rate to be the same as that of unicast
  Config::SetDefault ("ns3::WifiRemoteStationManager::NonUnicastMode",
                      StringValue (phyMode));
  
  MobilityHelper mob;
  Ptr<ListPositionAllocator> posList = CreateObject<ListPositionAllocator>();
  
  int nodes = 0;

  //initialization
  unsigned int now = (unsigned int)time( 0 );
  srand(now);
  
  NS_LOG_UNCOND("SIZE : " << SIZE*3 << " * " << SIZE*3);
  NS_LOG_UNCOND("NUMBER OF DRON : " << SET);
  
  for( int erea = 1; erea <= 9; erea++)
    {
      int num;
      if(erea == 5)
	{
	  continue;
	}
      else
	{
	  num = NODE_NUM_POINT;
	}
      
      for(int i = 0; i < num; i++)
	{
	  int x = rand() % SIZE;
	  int y = rand() % SIZE;
	  if(x == y){
	    i--;
	    continue;
	  }
	  switch(erea)
	    {
	    case 1:
	      break;
	    case 2:
	      x += SIZE;
	      break;
	    case 3:
	      x += SIZE * 2;
	      break;
	    case 4:
	      y += SIZE;
	      break;
	    case 5: //処理しないけど
	      x += SIZE;
	      y += SIZE;
	      break;
	    case 6:
	      x += SIZE * 2;
	      y += SIZE;
	      break;
	    case 7:
	      y += SIZE * 2;
	      break;
	    case 8:
	      x += SIZE;
	      y += SIZE * 2;
	      break;
	    case 9:
	      x += SIZE * 2;
	      y += SIZE * 2;
	      break;
	    default:
	      break;
	    }
	  
	  if( erea == 5 ) 
	    posList->Add(Vector(x,y,1));
	  else
	    posList->Add(Vector(x,y,0));
	}
      nodes += num;
    }
  
  // output
  NS_LOG_UNCOND("Number of nodes in a Residential scatterd area  :  " << nodes);
  
  //Determining Source and Destination
  int cnt = 0;
  std::list<std::pair<uint16_t,uint16_t>> souce_and_destination;
  srand((unsigned int)time(NULL));
  for(int i=0; i<SET;i++)
    {
      std::pair<uint16_t,uint16_t> s_d;
      s_d.first = rand() % nodes;
      s_d.second = rand() % nodes;
      bool flag = true;
      if(s_d.first == s_d.second)
	flag = false;
      for(auto pair : souce_and_destination)
	{
	  if(pair.second == s_d.second) // || pair.second == s_d.second)
	    flag = false;
	}
      if(flag)
	{
	  souce_and_destination.push_back(s_d);
	  cnt++;
	}
      else
	{
	  i--;
	}
    }


  for(int i = 0; i < NODE_NUM_CON; i++)
    {
      int x = rand()%SIZE;
      int y = rand()%SIZE;
      if(x == y){
	i--;
	continue;
      }
      x += SIZE;
      y += SIZE;
      posList->Add(Vector(x,y,1));
      nodes++;
    }
  // output
  NS_LOG_UNCOND("Number of nodes in a densely populated area  :  " << NODE_NUM_CON);
  
  mob.SetPositionAllocator(posList);
  NS_LOG_UNCOND(nodes);
  NodeContainer c;
  c.Create (nodes);

  // The below set of helpers will help us to put together the wifi NICs we want
  WifiHelper wifi;
  if (verbose)
    {
      wifi.EnableLogComponents ();  // Turn on all Wifi logging
    }

  YansWifiPhyHelper wifiPhy =  YansWifiPhyHelper::Default ();
  // set it to zero; otherwise, gain will be added
  wifiPhy.Set ("RxGain", DoubleValue (0) );
  // ns-3 supports RadioTap and Prism tracing extensions for 802.11b
  wifiPhy.SetPcapDataLinkType (WifiPhyHelper::DLT_IEEE802_11_RADIO);

  YansWifiChannelHelper wifiChannel;
  wifiChannel.SetPropagationDelay ("ns3::ConstantSpeedPropagationDelayModel");
  //wifiChannel.AddPropagationLoss ("ns3::FriisPropagationLossModel","Rss",DoubleValue(-10));
  wifiChannel.AddPropagationLoss ("ns3::RangePropagationLossModel","MaxRange",DoubleValue(1500));
  
  // wifiChannel.AddPropagationLoss ("ns3::FixedRssLossModel","Rss",DoubleValue(-10));
  wifiPhy.SetChannel (wifiChannel.Create ());

  // Add an upper mac and disable rate control
  WifiMacHelper wifiMac;
  wifi.SetStandard (WIFI_PHY_STANDARD_80211b);
  wifi.SetRemoteStationManager ("ns3::ConstantRateWifiManager",
                                "DataMode",StringValue (phyMode),
                                "ControlMode",StringValue (phyMode));
  // Set it to adhoc mode
  wifiMac.SetType ("ns3::AdhocWifiMac");
  NetDeviceContainer devices = wifi.Install (wifiPhy, wifiMac, c);

  mob.Install (c);

  // Enable OLSR
  OlsrHelper olsr;
  Ipv4StaticRoutingHelper staticRouting;

  Ipv4ListRoutingHelper list;
  list.Add (staticRouting, 0);
  list.Add (olsr, 10);

  InternetStackHelper internet;
  internet.SetRoutingHelper (list); // has effect on the next Install ()
  internet.Install (c);

  Ipv4AddressHelper ipv4;
  NS_LOG_INFO ("Assign IP Addresses.");
  ipv4.SetBase ("10.1.0.0", "255.255.0.0");
  Ipv4InterfaceContainer i = ipv4.Assign (devices);

  int pair_num = 0;
  TypeId tid = TypeId::LookupByName ("ns3::UdpSocketFactory");
  std::list<Ptr<Socket>> recvSinks;
  std::list<Ptr<Socket>> sources;
  for(auto pair : souce_and_destination)
    {
      
      Ptr<Socket> recvSink = Socket::CreateSocket (c.Get (pair.first), tid);
      InetSocketAddress local = InetSocketAddress (Ipv4Address::GetAny (), 80);
      recvSink->Bind (local);
      recvSink->SetRecvCallback (MakeCallback (&ReceivePacket));
      recvSinks.push_back(recvSink);

      
      Ptr<Socket> source = Socket::CreateSocket (c.Get (pair.second), tid);
      InetSocketAddress remote = InetSocketAddress (i.GetAddress (pair.first, 0), 80);
      source->Connect (remote);
      sources.push_back(source);
      NS_LOG_UNCOND("No." << pair_num << "   pair-->\t" << pair.first << "\t" << pair.second);
      pair_num++;
      //NS_LOG_UNCOND(pair_num);
    }
  
  if (tracing == true)
    {
      AsciiTraceHelper ascii;
      wifiPhy.EnableAsciiAll (ascii.CreateFileStream ("gunji-olsr.tr"));
      wifiPhy.EnablePcap ("gunji-olsr", devices);
      // Trace routing tables
      
      Ptr<OutputStreamWrapper> neighborStream = Create<OutputStreamWrapper> ("gunji-olsr.neighbors", std::ios::out);
      olsr.PrintNeighborCacheAllEvery (Seconds (44), neighborStream);
      // To do-- enable an IP-level trace that shows forwarding events only
    }

  Ptr<OutputStreamWrapper> routingStream = Create<OutputStreamWrapper> ("gunji-olsr.routes", std::ios::out);
  olsr.PrintRoutingTableAllEvery (Seconds (5), routingStream);

  int times = 0;
  for(Ptr<Socket> source : sources)
    {
      // Give OLSR time to converge-- 30 seconds perhaps
      Simulator::Schedule (Seconds ((32.0+DELAY*times)), &GenerateTraffic,
			   source, packetSize, numPackets, interPacketInterval);
      times++;
    }
  
  // Create the animation object and configure for specified output
  // AnimationInterface anim ("gunji-olsr-2.xml");
  // anim.EnablePacketMetadata (); // Optional
  //anim.EnableIpv4L3ProtocolCounters (Seconds (0), Seconds (40)); // Optional

  // Output what we are doing
  //NS_LOG_UNCOND ("Testing from node " << sourceNode << " to " << sinkNode);

  Simulator::Stop (Seconds (37.0+DELAY*times));
  Simulator::Run ();
  Simulator::Destroy ();
  
  return 0;
}

